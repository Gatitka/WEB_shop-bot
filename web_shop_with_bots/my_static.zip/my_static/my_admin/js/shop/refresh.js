document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        location.reload();
    }, 30000);  // 30000 миллисекунд = 30 секунд
});
